/*
 *
 *
脚本功能：麻豆视频解锁会员
软件版本：3.2.0
下载地址：https://shrtm.nu/mdsp
脚本作者：Hausd0rff
更新时间：2021.11.8
脚本发布：https://t.me/yqc_123
问题反馈：https://t.me/yqc_007
使用声明：⚠️此脚本仅供学习与交流，
        请勿转载与贩卖！⚠️⚠️⚠️
脚本说明：注册时填写邀请码：0c42ww 
         可无限延长脚本的使用期限

******************************

[rewrite_local]

# 麻豆视频解锁会员
^https?:\/\/api\.(md-ddd1|yh-bzd)\.com\/api\/web\/.+ url script-request-header https://raw.githubusercontent.com/yqc007/QuantumultX/master/MDSPCrack.js

[mitm] 

hostname = api.(md-ddd1|yh-bzd).com
*
*
*/


;var encode_version = 'jsjiami.com.v5', lrqtj = '__0xd1877',  __0xd1877=['fsOCwqp+w48=','w4IbeU7DlQ==','w5DDpQ9vw5g=','KAjCm8Kyw5Q=','CMK9w7zDnQI=','woVOe8OAw7A=','P8KyTUrCt07DvA==','wrbDmMOMw5cFwoLCkMO/w6HCmBHCpQ==','wo3CjMKgw77DqcKDwqxWw6Faw63CmcOfwrzCiyFma3huwr3DpURgwqJbasOeKsOSXcKwJCszRcKhDcOzMgfCmcOFFRA=','fMKfFDDDgHTDuwvCmGrCgRTDrsKhbcKrFg==','woDDmcKWDsK3JVDDgDbCjQfDt8O0wqw9w6E4wroLwonDjcKBDwNJP1JHw5YCGMKJw4glw7bDrsO8wpLDpChYw5ZFd8KEwofDlMKEwpbCm8ODZCojacOFw4Anwq/DmsK0w55LXWdxPGwNLllSw6kAw5BuVQNjTXnCogE2OsKdwpseNBdURMOUD8K1wrzCkF0KWMKHSMOFwqkow5/CuggoYcOXw7x9w4N2FcO7wqxAwrEgwofCjUHCt8OQAGJfw4rDliDClsOUO8KpwrZURHLCiMOYw7DCvmbCqcOJccKFSUHDr1dlFCjDmsKGw4zCuHwjUQPDuExPwovDswjDqcOWw7jCgsOOHGHDjcOiw7Bzw6xgw71vEsKnIMKpasOWMGbDq8KGwpXDmsO5ZMOyCsKl','QcOAIw==','fwxtw7zDgntYWCw=','PcKkRkfCs1HDpkNPwq3Duw7ClQ0=','54mc5p6B5Y+n772xwp7DouS/jeWtpeafoOW8sueqlu+9g+i8ueismOaUmuaOi+aIvuS5hOebluW2mOS8hw==','5Yu96Zmv54mh5p6r5Y2W77+ewrZF5L2j5a+C5p6y5byV56ug','d0U/WDc=','wohEQMOBw40='];(function(_0x2814,_0x4b5534){var _0x4b2483=function(_0x2c067a){while(--_0x2c067a){_0x2814['push'](_0x2814['shift']());}};_0x4b2483(++_0x4b5534);}(__0xd1877,0x1ec));var _0x2b77=function(_0x356655,_0x43b77c){_0x356655=_0x356655-0x0;var _0x240dbd=__0xd1877[_0x356655];if(_0x2b77['initialized']===undefined){(function(){var _0x260a46=typeof window!=='undefined'?window:typeof process==='object'&&typeof require==='function'&&typeof global==='object'?global:this;var _0x4c040d='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x260a46['atob']||(_0x260a46['atob']=function(_0x1289ec){var _0x2c397c=String(_0x1289ec)['replace'](/=+$/,'');for(var _0x48f436=0x0,_0x2ab21f,_0x8ac131,_0x4999dc=0x0,_0x4d2059='';_0x8ac131=_0x2c397c['charAt'](_0x4999dc++);~_0x8ac131&&(_0x2ab21f=_0x48f436%0x4?_0x2ab21f*0x40+_0x8ac131:_0x8ac131,_0x48f436++%0x4)?_0x4d2059+=String['fromCharCode'](0xff&_0x2ab21f>>(-0x2*_0x48f436&0x6)):0x0){_0x8ac131=_0x4c040d['indexOf'](_0x8ac131);}return _0x4d2059;});}());var _0x530501=function(_0x400809,_0x48226e){var _0x3e1a65=[],_0x2a0f13=0x0,_0x12c7eb,_0xfa95ef='',_0x29125b='';_0x400809=atob(_0x400809);for(var _0x38ffad=0x0,_0x41c1d4=_0x400809['length'];_0x38ffad<_0x41c1d4;_0x38ffad++){_0x29125b+='%'+('00'+_0x400809['charCodeAt'](_0x38ffad)['toString'](0x10))['slice'](-0x2);}_0x400809=decodeURIComponent(_0x29125b);for(var _0x3f6ebf=0x0;_0x3f6ebf<0x100;_0x3f6ebf++){_0x3e1a65[_0x3f6ebf]=_0x3f6ebf;}for(_0x3f6ebf=0x0;_0x3f6ebf<0x100;_0x3f6ebf++){_0x2a0f13=(_0x2a0f13+_0x3e1a65[_0x3f6ebf]+_0x48226e['charCodeAt'](_0x3f6ebf%_0x48226e['length']))%0x100;_0x12c7eb=_0x3e1a65[_0x3f6ebf];_0x3e1a65[_0x3f6ebf]=_0x3e1a65[_0x2a0f13];_0x3e1a65[_0x2a0f13]=_0x12c7eb;}_0x3f6ebf=0x0;_0x2a0f13=0x0;for(var _0x1885c9=0x0;_0x1885c9<_0x400809['length'];_0x1885c9++){_0x3f6ebf=(_0x3f6ebf+0x1)%0x100;_0x2a0f13=(_0x2a0f13+_0x3e1a65[_0x3f6ebf])%0x100;_0x12c7eb=_0x3e1a65[_0x3f6ebf];_0x3e1a65[_0x3f6ebf]=_0x3e1a65[_0x2a0f13];_0x3e1a65[_0x2a0f13]=_0x12c7eb;_0xfa95ef+=String['fromCharCode'](_0x400809['charCodeAt'](_0x1885c9)^_0x3e1a65[(_0x3e1a65[_0x3f6ebf]+_0x3e1a65[_0x2a0f13])%0x100]);}return _0xfa95ef;};_0x2b77['rc4']=_0x530501;_0x2b77['data']={};_0x2b77['initialized']=!![];}var _0xb41566=_0x2b77['data'][_0x356655];if(_0xb41566===undefined){if(_0x2b77['once']===undefined){_0x2b77['once']=!![];}_0x240dbd=_0x2b77['rc4'](_0x240dbd,_0x43b77c);_0x2b77['data'][_0x356655]=_0x240dbd;}else{_0x240dbd=_0xb41566;}return _0x240dbd;};var modifiedHeaders=$request[_0x2b77('0x0','3okl')];modifiedHeaders[_0x2b77('0x1','NN@N')]=_0x2b77('0x2','QzQY');modifiedHeaders[_0x2b77('0x3','pc%T')]=_0x2b77('0x4','3deh');$done({'headers':modifiedHeaders});;(function(_0x5ce054,_0x406e56,_0x5ad0e7){var _0x4a72cb={'nxLdA':_0x2b77('0x5','pc%T'),'UOiFl':function _0x50b275(_0x308bb2,_0x4ec095){return _0x308bb2!==_0x4ec095;},'vdBVJ':_0x2b77('0x6','IejK'),'zwKbM':function _0x1a1324(_0x143bbf,_0x4e0d24){return _0x143bbf===_0x4e0d24;},'owOpv':_0x2b77('0x7','3okl'),'nJCUy':function _0x5b4af2(_0x57fba8,_0x4f3a1b){return _0x57fba8+_0x4f3a1b;},'MgMJc':_0x2b77('0x8','B8SB'),'XERGQ':_0x2b77('0x9','dvUU')};_0x5ad0e7='al';try{_0x5ad0e7+=_0x4a72cb[_0x2b77('0xa','Y[0$')];_0x406e56=encode_version;if(!(_0x4a72cb[_0x2b77('0xb','dvUU')](typeof _0x406e56,_0x4a72cb[_0x2b77('0xc','tOwZ')])&&_0x4a72cb[_0x2b77('0xd','gaa)')](_0x406e56,_0x4a72cb[_0x2b77('0xe','3sYg')]))){_0x5ce054[_0x5ad0e7](_0x4a72cb[_0x2b77('0xf','0cIa')]('删除',_0x4a72cb[_0x2b77('0x10','FN1k')]));}}catch(_0x527732){_0x5ce054[_0x5ad0e7](_0x4a72cb[_0x2b77('0x11','dvUU')]);}}(window));;encode_version = 'jsjiami.com.v5';
