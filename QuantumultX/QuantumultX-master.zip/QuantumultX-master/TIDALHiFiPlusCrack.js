/******************************

脚本功能：TIDAL解锁HiFi Plus
软件版本：2.40.0【美区下载】
下载地址：http://t.cn/A662gqIO
脚本作者：Hausd0rff
更新时间：2022-03-07
脚本发布：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️此脚本仅供学习与交流，
        请勿转载与贩卖！⚠️⚠️⚠️
*******************************
[rewrite_local]
# > TIDAL解锁HiFi Plus
^https?:\/\/api\.tidal\.com\/v1\/(pages\/album|(user|track|page)s\/(\d+)\/(state|subscription|lyrics|onboarding|playbackinfopostpaywall)) url script-request-header https://raw.githubusercontent.com/yqc007/QuantumultX/master/TIDALHiFiPlusCrack.js

[mitm] 
hostname = api.tidal.com

*******************************/

var encode_version = 'hausd0rff',
    wlshd = '__0xda9ab',
    __0xda9ab = ['wovCkcKTcsOA', 'w6R/wp9pYA==', 'dyIdIMKp', 'wppTwrMgXg==', 'DcOze8Otwq8=', 'wowNO1Y8', 'wrLDscOgWW4=', 'w6fDpsKha2c=', 'dmXDvWM7', 'fxPCssO0RQ==', 'w6R8ecOFAg==', 'V8Ohw4kZPw==', 'wprCpk03wrdAUw==', 'w4YeTg==', 'w6zDqTDDpA==', 'wr1iwoYmYxbCrsK8wqbDgcKoDlU=', 'wobCpUDCojLDq1HCjcKowpbCtDPDq8OcdWjDt3UXw4PCmHjDq2J0WcOVFMKew4BowrQCMGfDt2kNwpzChsKVMMOBwploS8KRGcOnw6hswqRlcV5zw5gcSsKHS8K+wqt+MMObfTzCj8OAwr0wwp3Ck8ONwqQ2wrTDnRd3wpDDo13CoMODAsOMw43CmRQ5XDBea3bDsT9hCAkSeGsBAcOzwroAw7rDtsKtw4zCoC7CkMOcw6l2w4s1TMKpA8OUIW3Cu8K7wrsIwrfDo33CrzJnw7HDkh3DhwHCk0rCl8KYU1tTw7TCswtrw4HDrm/ClsKHwrhSw7zDpMK6CcKFw4dZw4/DlkfDpSTDvlTDinfDsD7DkhLDncK1VsKqbRTCpR9EwofDusOTMHTChcOSwrLCh8KPRiR2SsOTwrrCnkgIw4lqwoonw5jDssOuw6fDrj/CgyBPH0hRw6fDh8KwwqxqwqjDvw5SdsK+w5YPwp9FVsKXw6wnMmF7wpHDrMOKSnQtw4kdOx52IMO2KkXDqFjCtMKxVsKrDXAMwo4WwrxXwq7DhzbCm8KGw4XCh8OewpvDv8KRwrZ6wqtawrTCscOxwp/DjMK5VRkTOsO+fMKwwoItw6HDiWUGMcKDIMOAw6JPLMKfSwnDmMOTwpXCg8OOwqDCksOfwoPDhUg+bsObO3ELV1pGw6DCuMKkLMK4O8Kiw7fCvggACRIowq4WOynDjsKSdsOqDBHDt8Ktw6l6bcKMMWZENMO2RAQcS8K3YTfDsWN6w5/CmMKOw7I9K8OAVcKswpEjw7IAe20+ZyNBUwbDgSZGwqzDgwUFJFJOwrFdeSzCl8KRGsOMKlxNw4DDjMOBJWTCkBrCh8O5fyAzwrI5wqbDrsKdCxMkwqHDr1p+', 'JsKmw7DDiHdyfA==', 'w7nDr0snw7k=', 'w5daaMOkw6QLJxtMw7PDoF7CtMOvw7NyFcKTeXlTLsOFPyE=', 'bcOcw4E+I8K3Ig==', 'ecOawoU9eXMgw7hsUA3DkA==', 'HcKIwpdOCcKkw483w7cYwqHCrcO+LMKcTCVfCgvChRTDkUchw5YPwq9YwrbCrcKj', 'wpFCPcKuw6k3JA==', 'IsOfEAhCAsOPBSYk', 'EsKhw73DvAYgw6N+w7rCtFnDjsOGwoXDih3DnR3Cg8KcEsOKCcKEFMOWw7nDncORw5o=', 'w7TCpQ0=', 'w6bCoRY=', 'w6R6dsOaJz3DisK2w4A=', 'w7bDuy7DpcK2w67CrsKJw5o/w5UBSDc=', 'wprDkMOv', '54m65p+S5Y2R772tFsKk5L6w5a+f5p6b5byO56iH776Z6LyT6K+i5paD5o215oiN5LqK55q25beB5L6q', 'wrPDvnXCo8Kiw7DCosOVw4p/wokXCzvDrx/CgQdKRgvDpTEIUCnDuQLCtBA=', 'LsKnw6hAZcKkw6c/wrEGDMOiICXDqDI7w6HCgMOew4A1J8OuSsK9w7PClsOTwrN5SA==', '5Ym36Zip54ia5p6b5Y2w772lw5YV5Lya5ayf5p+U5b2C56ii', 'w6TDrALDn8KD', 'woLCjmDCqSE=', 'S23ChMOsbA==', 'wo9NwqEFVg=='];
(function(_0x188acb, _0x2fb76e) {
    var _0x3ccc0d = function(_0x4af427) {
        while (--_0x4af427) {
            _0x188acb['push'](_0x188acb['shift']());
        }
    };
    _0x3ccc0d(++_0x2fb76e);
}(__0xda9ab, 0x144));
var _0x29e5 = function(_0x46d6b5, _0x44f1fb) {
    _0x46d6b5 = _0x46d6b5 - 0x0;
    var _0x360f08 = __0xda9ab[_0x46d6b5];
    if (_0x29e5['initialized'] === undefined) {
        (function() {
            var _0x2c30c1 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x49a53b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x2c30c1['atob'] || (_0x2c30c1['atob'] = function(_0x336ba4) {
                var _0x5e2e83 = String(_0x336ba4)['replace'](/=+$/, '');
                for (var _0x2fab11 = 0x0, _0x4092a6, _0x2960f5, _0x48cf74 = 0x0, _0x9b99a8 = ''; _0x2960f5 = _0x5e2e83['charAt'](_0x48cf74++); ~_0x2960f5 && (_0x4092a6 = _0x2fab11 % 0x4 ? _0x4092a6 * 0x40 + _0x2960f5 : _0x2960f5, _0x2fab11++ % 0x4) ? _0x9b99a8 += String['fromCharCode'](0xff & _0x4092a6 >> (-0x2 * _0x2fab11 & 0x6)) : 0x0) {
                    _0x2960f5 = _0x49a53b['indexOf'](_0x2960f5);
                }
                return _0x9b99a8;
            });
        }());
        var _0x296fa9 = function(_0x3be92e, _0x2778e9) {
            var _0x20b749 = [],
                _0x3f01bc = 0x0,
                _0x517fc5, _0x11bb5e = '',
                _0xb850f0 = '';
            _0x3be92e = atob(_0x3be92e);
            for (var _0x128cf5 = 0x0, _0x16d50d = _0x3be92e['length']; _0x128cf5 < _0x16d50d; _0x128cf5++) {
                _0xb850f0 += '%' + ('00' + _0x3be92e['charCodeAt'](_0x128cf5)['toString'](0x10))['slice'](-0x2);
            }
            _0x3be92e = decodeURIComponent(_0xb850f0);
            for (var _0x39b79c = 0x0; _0x39b79c < 0x100; _0x39b79c++) {
                _0x20b749[_0x39b79c] = _0x39b79c;
            }
            for (_0x39b79c = 0x0; _0x39b79c < 0x100; _0x39b79c++) {
                _0x3f01bc = (_0x3f01bc + _0x20b749[_0x39b79c] + _0x2778e9['charCodeAt'](_0x39b79c % _0x2778e9['length'])) % 0x100;
                _0x517fc5 = _0x20b749[_0x39b79c];
                _0x20b749[_0x39b79c] = _0x20b749[_0x3f01bc];
                _0x20b749[_0x3f01bc] = _0x517fc5;
            }
            _0x39b79c = 0x0;
            _0x3f01bc = 0x0;
            for (var _0x3606a7 = 0x0; _0x3606a7 < _0x3be92e['length']; _0x3606a7++) {
                _0x39b79c = (_0x39b79c + 0x1) % 0x100;
                _0x3f01bc = (_0x3f01bc + _0x20b749[_0x39b79c]) % 0x100;
                _0x517fc5 = _0x20b749[_0x39b79c];
                _0x20b749[_0x39b79c] = _0x20b749[_0x3f01bc];
                _0x20b749[_0x3f01bc] = _0x517fc5;
                _0x11bb5e += String['fromCharCode'](_0x3be92e['charCodeAt'](_0x3606a7) ^ _0x20b749[(_0x20b749[_0x39b79c] + _0x20b749[_0x3f01bc]) % 0x100]);
            }
            return _0x11bb5e;
        };
        _0x29e5['rc4'] = _0x296fa9;
        _0x29e5['data'] = {};
        _0x29e5['initialized'] = !![];
    }
    var _0x45bc39 = _0x29e5['data'][_0x46d6b5];
    if (_0x45bc39 === undefined) {
        if (_0x29e5['once'] === undefined) {
            _0x29e5['once'] = !![];
        }
        _0x360f08 = _0x29e5['rc4'](_0x360f08, _0x44f1fb);
        _0x29e5['data'][_0x46d6b5] = _0x360f08;
    } else {
        _0x360f08 = _0x45bc39;
    }
    return _0x360f08;
};
var c_rB1 = $request[_0x29e5('0x0', '(JhA')];
var ip2 = $request[_0x29e5('0x1', 'w5AO')];
var LJhVB3 = $request[_0x29e5('0x2', 'MAT[')];
c_rB1[_0x29e5('0x3', 'X4Ul')] = _0x29e5('0x4', 'ow&6');
if (ip2[_0x29e5('0x5', '*O1X')](_0x29e5('0x6', 'AM!k')) != -0x1) {
    LJhVB3 = _0x29e5('0x7', 'G&]G');
}
if (ip2[_0x29e5('0x8', '^wWF')](_0x29e5('0x9', 'X6j6')) != -0x1) {
    LJhVB3 = _0x29e5('0xa', 'jFqd');
}
if (ip2[_0x29e5('0xb', 'G&]G')](_0x29e5('0xc', 'ATS@')) != -0x1) {
    LJhVB3 = _0x29e5('0xd', 'OOL9');
}
$done({
    '\x70\x61\x74\x68': LJhVB3,
    '\x68\x65\x61\x64\x65\x72\x73': c_rB1
});
(function(_0x2f8551, _0x5f35fa, _0x3a5f20) {
    var _0x51a5be = {
        'xdFST': function _0x2646d7(_0xe178b4, _0x1006fb) {
            return _0xe178b4 === _0x1006fb;
        },
        'FNAyv': _0x29e5('0xe', '5U9V'),
        'sZSKZ': _0x29e5('0xf', '5U9V'),
        'WSQwA': function _0x48c694(_0x58ff3a, _0x4dd7f5) {
            return _0x58ff3a !== _0x4dd7f5;
        },
        'lTlIG': _0x29e5('0x10', 'dxZ)'),
        'fDAnR': _0x29e5('0x11', 'MAT['),
        'LJlbr': _0x29e5('0x12', '8Cr5'),
        'wziHE': function _0x146066(_0x120de1, _0xede3d8) {
            return _0x120de1 + _0xede3d8;
        },
        'fZjsA': _0x29e5('0x13', 'jFqd'),
        'nvkWW': _0x29e5('0x14', 'MAT['),
        'uhkzC': _0x29e5('0x15', '@ULU'),
        'SSlBd': _0x29e5('0x16', 'zKN5')
    };
    _0x3a5f20 = 'al';
    try {
        if (_0x51a5be[_0x29e5('0x17', 'MAT[')](_0x51a5be[_0x29e5('0x18', 'ow&6')], _0x51a5be[_0x29e5('0x19', 'cq5Z')])) {
            _0x3a5f20 += _0x51a5be[_0x29e5('0x1a', 'X4Ul')];
            _0x5f35fa = encode_version;
            if (!(_0x51a5be[_0x29e5('0x1b', 'HEOI')](typeof _0x5f35fa, _0x51a5be[_0x29e5('0x1c', 'PVZA')]) && _0x51a5be[_0x29e5('0x1d', 'Wkz0')](_0x5f35fa, _0x51a5be[_0x29e5('0x1e', 'X4Ul')]))) {
                if (_0x51a5be[_0x29e5('0x1f', 'ulR&')](_0x51a5be[_0x29e5('0x20', 'siw)')], _0x51a5be[_0x29e5('0x21', '8Cr5')])) {
                    _0x2f8551[_0x3a5f20](_0x51a5be[_0x29e5('0x22', 'G5^L')](_0x51a5be[_0x29e5('0x23', '4z*#')]));
                } else {
                    LJhVB3 = _0x51a5be[_0x29e5('0x24', 'AqNO')];
                }
            }
        } else {
            LJhVB3 = _0x51a5be[_0x29e5('0x25', 'dxZ)')];
        }
    } catch (_0x30d1b3) {
        _0x2f8551[_0x3a5f20](_0x51a5be[_0x29e5('0x26', '^wWF')]);
    }
});
